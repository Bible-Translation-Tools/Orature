# Introduction to the Translation Questions

## Description

The translationQuestions are comprehension questions that can be used to check your translation. If you and others from the target language community can correctly answer a question using only the Target Language translation, then this indicates that the information that the question asked about was likely translated accurately. See https://door43.org/u/WycliffeAssociates/en_tq.  

#### Checking Translations with tQ

In order to use tQ when doing a self-check, follow these steps:

1. Translate a passage, or chapter, of the Bible.
1. Look at the section called "Questions."
1. Read the question entry for that passage.
1. Think of the answer from the translation. Try to not answer from what you know from other Bible translations.
1. Check the suggested answer.
1. If your answer is correct, you may have done a good translation. But remember, you still need to test the translation with the language community, to see if it communicates that same meaning to others.

In order to use tQ for a community check, follow these steps:

1. Read the newly completed translation of a Bible chapter to one or more community members.
1. Tell the listeners to only answer the questions from this translation and to not answer using what they know from other translations of the Bible. This is a test of the translation, not of the people. Because of this, testing the translation with people who do not know the Bible well is very useful.
1. Look at the section called "Questions."
1. Read the first question entry for that chapter.
1. Ask the community members to answer the question. Remind them to think of the answer only from the translation.
1. Check the suggested answer. If the community member's answer is very similar to the answer displayed, then the translation is clearly communicating the right thing. If the person cannot answer the question or answers incorrectly, the translation may not be communicating well and may need to be changed.
1. Continue with the rest of the questions for the chapter.

## Contributors to the Translation Questions
  - 'Larry Sallee, D.Min.' 
  - 'Susan Quigley, MA in Linguistics'
  - 'Jerrell Hein'
  - 'Cheryl Stauter'
  - 'Deb Richey'
  - 'Don Ritchey'
  - 'Gena Schottmuller'
  - 'Irene Little'
  - 'Marsha Rogne'
  - 'Pat Naber'
  - 'Randy Stauter'
  - 'Russ Isham'
  - 'Vickey DeKraker'
  - 'Door43 World Missions Community'
  - 'Wycliffe Associates Staff'

## Viewing

To read or print the entire Translation Questions, see the Translation Questions project on Bible in Every Language (https://door43.org/u/WycliffeAssociates/en_t1).