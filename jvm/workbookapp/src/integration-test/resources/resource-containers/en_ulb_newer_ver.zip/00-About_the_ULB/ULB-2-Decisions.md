# Decisions Concerning the ULB
The following are decision that have been made concerning the ULB. This is not a comprehensive list, but it is here to remind current editors and to inform future editors of some important ones.
## ULB Style
The following are details concerning the use of punctuation, capitalization, and vocabulary  in the ULB.
  * Quotation marks are used at the beginning and ending of direct speech. They are not used at the beginning of each verse, even though the speech may span several verses.
  * Contractions are not used in the ULB.
  * Punctuation is normally (not always) inside the quotation marks. 
  * Capitalization issues: in general, we follow the practice of the 2011 NIV.
  * Titles are capitalized. (Son of Man, King David, the Messiah).
  * All pronouns are lower case (except when beginning sentences and except for the first singular "I").
  * Spelling of names, in most cases, follows that used in the 2011 NIV. (This includes translating Ἑβραϊστί as "Aramaic (language)."
  * Where possible, the ULB editors have used common vocabulary that is easy to translate into another language.
## Translation Glossaries
A list of decisions as to how to translate some senses of the source language words and phrases into another language is called a translation glossary. Such a device is especially useful when more than one person works on the same project, because it helps keep everyone using the same English terms.
However, the sources often use some words to signal more than one sense, depending on context. A translation glossary is therefore a glossary of word senses, not a glossary of words. Check back often to this page, because these glossaries are likely to develop for the entire life of WA's translation resources project.
Note that occasionally, the translation glossary's specified translation will not be suitable. As always, the text editors must remain in control of the decision-making process. The glossaries are to guide you as much as is possible. If you must depart from the glossary guidelines, do so and insert a note in the relevant glossary below to that effect.
### Limited Translation Glossary for the ULB
This first list concerns English words used in the ASV of both the Old and New Testaments. Preferred English renderings appear in bold type.
  * *And* (sentence-initial): The ULB only rarely uses sentence-initial "And." Occurrences of sentence-initial "and" in the ASV usually occur where the ASV translates the preverbal Greek particle *kai* or the Hebrew *vav* in the *wayyiqtol* verb form. The Greek particle *kai* was usually a Hebraism on the part of the New Testament writers that reflected their understanding that the Hebrew *wayyiqtol* form contained the conjunctive *vav* 'and.' This, however, was a misunderstanding, for modern scholarship has shown that the *wayyiqtol* form was a frozen form with parallels in cognate Semitic languages; it was the preferred Hebrew verb form for signaling event verbs in Hebrew narration.
  * *Shall*: "**will**" for future expressions in general;
    *  "**should**", "**must**", or direct command for  obligation; 
    *  "**shall**" in prophecies, blessings, curses, and other passages focusing on the speaker's intentionality, e.g., 
      *  "Yahweh said, 'Shall I hide from Abraham what I am about to do...?'" (Genesis 18:17)
      *  "A deliverer shall come to Zion,"
      *  "every mountain and hill shall be made low."
  * In speech introductions that use two verbs such as, "he answered and said," the ULB often retains this formula by using **both verbs**. This provides a model for languages which also separate the mode of speech from the act of speech.
  * *Brethren*: "**brothers**" both when it refers only to men and when it refers to both men and women. 
  * *Call* in the ASV usage "**call his name**": "**call him**" or "**name him**"
  * *Call* in the formula of the type, "**he shall be called** the Son of the Most High" (Luke 1:32): The ULB keeps this formula, but be aware of the metaphor that is operative here: in this verse, Jesus will not only be called the Son of the Most High, but he will be the Son of the Most High.
  * *Hand* indicating power or possession:  The ULB keeps this metaphor except when it would add confusion
  * Expressions of the type, "he knew his wife" or "he went into his wife" are usually translated in the ULB as "**he lay with his wife**." The expressions "**had sexual relations**" and "**slept with**" are also used. 
### Limited Translation Glossary for the Old Testament ULB
This list concerns Hebrew words in the Old Testament. 
  * *wayehi* "**It came about**" or "**It happened that**"
  * *hinneh* "**look**," "**see**," "**see here**," or something else suitable for signaling that what immediately follows in direct reported speech is prominent. 
    * Often "**behold**" in direct reported speech of God or his angel, especially if it lends more dignity in English to the divine words than "look" or "see," etc., would do.
    * Also "**behold**" in narrative passages, including narrative that is embedded in direct speech, such as when Joseph tells his brothers what happened in his dreams)
  * *adam*: "**mankind**," "**humanity**," and "**human beings**" when it refers to mankind in general
  * *YHWH*: "**Yahweh**" 
### Limited Translation Glossary for the New Testament ULB
This list concerns Greek words in the New Testament. 
  * *egeneto de*, *kai egeneto*: "**It came about**" (See: "Sentence-initial and" above).
  * *idou*: "**look**," "**see**," "**see here**," or something else suitable for signaling that what immediately follows in direct reported speech is prominent. 
    * Often "**behold**" in direct reported speech of God or his angel, especially if it lends more dignity in English to the divine words than "look" or "see," etc., would do.
    * Also "**behold**" in narrative passages, including narrative that is embedded in direct speech.
  * *Xristos*: "**Christ**" or "**the Christ**" (The definite article is appropriate if the term is being clearly used as a title; Paul often seems to use *Xristos* as a second name for Jesus, but at times he clearly uses it as a title).
  * *Messias*: "**Messiah**" 
  * *anthropos*: "**mankind**," "**humanity**," or "**human beings**" when it refers to humanity in general
  * *nomikos*: "**expert in the law**" when it refers to a Jewish person rather than to the Jewish law itself and "**lawyer**" when it refers to an expert in some other kind of law.
  * *grammateus*: "**scribe**" when it refers to a religious scribe 
  * *hagioi*: "**holy people**" or "**God's holy people**" when it refers to people, 
    *  "**holy ones**" or "**holy angels**" when it refers to heavenly beings 
  * *euangelion*: "**gospel**” when it clearly refers to the gospel of salvation through Jesus Christ.
    * Otherwise, "**good news**."
  * *elpis*: "**hope**" as a noun
  * *elpizo*: "**hope**" as a verb or "set hope"
## Footnotes in the ULB
The ULB has footnotes for the following kinds of issues:  
* names that have multiple spellings
* people and places that have multiple names
* differences in Hebrew and Greek copies that lead to differences in modern versions
* alternative renderings of verses that are very hard to understand in the original languages
* differences between copies of the texts in the original languages and the early Greek and Latin translations
The notes use the following words in refering to copies and translations:    
* "Copies" refers to extant copies of the Biblical text, written in the original language, or to copies of the Septuagint or Vulgate.
* "Text" or "original text" refers to the Hebrew or Greek or Aramaic text compiled from all sources (that is, from all extant copies).
* "Translation" refers to ancient translations (the Septuagint and the Vulgate) and to modern translations.
* We do not use the words "manuscripts" and "versions" in the footnotes.
The ULB does not have footnotes for every textual issue, but it does address those that readers are most likely to encounter, particularly readers who have access to translations that were based on manuscripts known before the finding of the Dead Sea scrolls.